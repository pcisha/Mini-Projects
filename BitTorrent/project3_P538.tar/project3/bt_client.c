#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <netinet/in.h>
#include <netinet/ip.h> //ip hdeader library (must come before ip_icmp.h)
#include <netinet/ip_icmp.h> //icmp header
#include <arpa/inet.h> //internet address library
#include <netdb.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <signal.h>


#include "bencode.h"
#include "bt_lib.h"
#include "bt_setup.h"
#include "log.h"

char *calculateSHA1Info(be_dict dictType){
	char inputString[256] = {0};
	char digest[20] = {0};
	char *ch_pointer;
	char str1[19];
	snprintf(str1, sizeof(str1), "%lld", dictType.val->val.d[0].val->val.i);
	char str3[19];
	snprintf(str3, sizeof(str3), "%lld", dictType.val->val.d[2].val->val.i);

	strcat(inputString,str1);
	strcat(inputString,dictType.val->val.d[1].val->val.s);
	strcat(inputString,str3);
	strcat(inputString,dictType.val->val.d[3].val->val.s);
	//format print
	 // len = snprintf(inputString,256,"%s",inputString);

	  //id is just the SHA1 of the ip and port string
	  SHA1(inputString, strlen(inputString), digest);
	  char hashkeyChar[20];
	  int i;
	  				 for(i = 0; i < 20; i++)
	  					 sprintf(&hashkeyChar[i], "%02x", (unsigned int)digest[i]);

	  				ch_pointer = &hashkeyChar;
	  return ch_pointer;
}

int compareHandShake(char *str, be_node *node_p){
	char handshake[68] = {0};
	char bitTorrentName[19] = "BitTorrent protocol";
	char reservedBytes[8]= "00000000";
	handshake[0] = 19;
	//strncat(final_string, second_string[ text_position ], text_length);
	strncat(handshake, bitTorrentName, 19);
	strncat(handshake, reservedBytes, 8);
	strncat(handshake, calculateSHA1Info(node_p->val.d[2]), 20);
	int index=0;
		 for(index = 0; index < strlen(handshake); index++){
			 if(handshake[index]!=str[index])
				 break;
		 }
		 if(index==strlen(handshake)){
			 return 1;
		 }
		 else{
			 return 0;
		 }
}

int handleLeecherHandshake(int leecherSock, be_node *node_p, bt_args_t args_p){
	printf("in leecher hande code:%d",leecherSock);
	int rcvMsgSize;
	char str[68] = {0};
	int flag = 0;
	// receive msg from leecher
	if((rcvMsgSize = recv(leecherSock, str, 68, 0))>=0){
		printf("On the Seeder Side: %s",str);
		flag = compareHandShake(str,node_p);
		// this means the values received on the seeder side are correct
	}
	while(rcvMsgSize > 0){
		if(flag == 1){
			//send msg to leecher
			if(send(leecherSock,str,rcvMsgSize,0) != rcvMsgSize){
				printf("Error in send.");
			}
			flag = 0;
			//checking the final ACK MSG
			if((rcvMsgSize = recv(leecherSock,str,68,0))<0){
				printf("error in recv.");
				return flag;
			}else if(strncmp (str,"ACK",3) == 0){
				flag = 1;
				return flag;
			}
		}else if(flag == 0){
			return flag;
		}
	}
	return flag;
	//close(leecherSock);
}

void handleRequestMessages(int leecherSock, be_node *node_p, bt_args_t args_p){
	int i=0;
	while(i<1){
		printf("Ack received handshake done waiting to receive msgs");
		i++;
	}
}

void seederCode(be_node *node_p, bt_args_t args_p){
	int seederSock;
	int leecherSock;
	int handshakeFlag;
	struct sockaddr_in seederSocketAddress; //seeder address
	struct sockaddr_in leecherSocketAddress; //leecher address
	unsigned short seederPort;
	unsigned int leecherLen;
	char *s;
	char tempChar[4] = {0};
	s = node_p->val.d[0].val->val.s;
	tempChar[0] = s[strlen(s)-4];
	tempChar[1] = s[strlen(s)-3];
	tempChar[2] = s[strlen(s)-2];
	tempChar[3] = s[strlen(s)-1];
//	x = (int)(tempChar - 0);
	//node_p->val.d[0].val.val.s;tempChar = &s;

			if ((seederSock = socket(AF_INET, SOCK_STREAM, 0)) < 0)
				perror( "socket () failed");
				//s = node_p->val.d[0].val.val.s;

				seederPort = atoi(tempChar);
			// Construct local address structure
				memset(&seederSocketAddress, 0, sizeof(seederSocketAddress));
				seederSocketAddress.sin_family = AF_INET;
				seederSocketAddress.sin_addr.s_addr = htons(INADDR_ANY);
				seederSocketAddress.sin_port = htons(seederPort);

			/* Bind to the local address */
			if (bind(seederSock, (struct sockaddr *)&seederSocketAddress,sizeof(struct sockaddr_in)) < 0)
				perror ( "bind () failed");

			/* Mark the socket so it will listen for incoming connections */
				if (listen(seederSock, MAX_CONNECTIONS) < 0)
					perror("listen() failed") ;
				for (;;) /* Run forever */
			{
					leecherLen = sizeof(leecherSocketAddress);
					/* Set the size of the in-out parameter */
					/* Wait for a client to connect */
					if ((leecherSock = accept(seederSock, (struct sockaddr *) &leecherSocketAddress,&leecherLen)) >= 0){
						printf("accept() successful");
						handshakeFlag = handleLeecherHandshake(leecherSock,node_p,args_p);
						if(handshakeFlag==1){
							handleRequestMessages(leecherSock,node_p,args_p);
						}
					}
			}
				printf("seeder code terminating");
}

int sendReceiveLeecherHandshake(int socketId, be_node *node_p, bt_args_t args_p){
	char handshake[68] = {0};
	char bitTorrentName[19] = "BitTorrent protocol";
	char reservedBytes[8]= "00000000";
	handshake[0] = 19;
	int flagToCheckValidHandshake = 0;
	//strncat(final_string, second_string[ text_position ], text_length);
	strncat(handshake, bitTorrentName, 19);
	strncat(handshake, reservedBytes, 8);
	strncat(handshake, calculateSHA1Info(node_p->val.d[2]), 20);
	strncat(handshake, args_p.peers[1]->id, 20);
	// Write the 68 byte PeerWire handshake.
     send(socketId,handshake, 68,0);
     loggingfunc("handshake","send the first HS msg to seeder", args_p.log_file);
     //receive the response of the handshake
     recv(socketId,handshake,68,0);
     loggingfunc("handshake","received the 2nd HS msg from seeder", args_p.log_file);
     flagToCheckValidHandshake = compareHandShake(handshake,node_p);
     if(flagToCheckValidHandshake == 1){
    	 //send final ack msg
    	 send(socketId,"ACK Successfully sent", 68,0);
    	 return 1;
     }else{
    	 return 0;
     }
     /*totalBytesRcvd = 0;
     while(totalBytesRcvd<handshake){
    	 if((bytesRcvd = recv(socketId,handshake,68,0))<=0)
    		 printf("Error in recv");
    	 totalBytesRcvd += bytesRcvd;
    	 flagToCheckValidHandshake = compareHandShake(handshake,node_p);
    	 printf("Final received: %s", handshake);
     }*/
}

void leecherCode(be_node *node_p, bt_args_t args_p){
	int i = 0;
	int flag=0;
	int breakFlag = 1;

		printf("leecher code\n");
	     	int leecherSock;
	     	if((leecherSock = socket(AF_INET, SOCK_STREAM, 0))<0){
		  	printf("Socket connection error!");
		  }
	     	for(i=0;i<MAX_CONNECTIONS;i++){
	     	      if(args_p.peers[i] != NULL && (connect(leecherSock, (struct sockaddr*)&args_p.peers[i]->sockaddr,sizeof(struct sockaddr_in)) < 0))
	     	    	  perror("Connect");
	     	      else if(args_p.peers[i] != NULL){
	     	    	  //send leecher handshake
	     	    	 flag = sendReceiveLeecherHandshake(leecherSock,node_p, args_p);
	     	    	 /**
	     	    	  * note after this step the handshake has been established successfully if flag has 1
	     	    	  * in the while loop below the leecher will request for packets from the seeder using different messages
	     	    	  * the breakFlag parameter is used to break the while loop after the file has been received
	     	    	  */
	     	    	 	 	 if(flag == 1){
	     	    		     		while(breakFlag == 1){
	     	    		     			// create msg to request then have a SEND command here.
	     	    		     				printf("need to send a msg to ask for a file");
	     	    		     				breakFlag =0;
	     	    		     		     }
	     	    	}
	     	      }
	     	    }

	     	close(leecherSock);
		  	printf("leecher code terminating");
			exit(1);
}

int main (int argc, char * argv[]){

  bt_args_t bt_args;
  be_node * node; // top node in the bencoding
  int i;

  parse_args(&bt_args, argc, argv);


  if(bt_args.verbose){
    printf("Args:\n");
    printf("verbose: %d\n",bt_args.verbose);
    printf("save_file: %s\n",bt_args.save_file);
    printf("log_file: %s\n",bt_args.log_file);
    printf("torrent_file: %s\n", bt_args.torrent_file);

    for(i=0;i<MAX_CONNECTIONS;i++){
      if(bt_args.peers[i] != NULL)
        print_peer(bt_args.peers[i]);
    }
  }

  //read and parse the torrent file
  node = load_be_node(bt_args.torrent_file);

  if(bt_args.verbose){
    be_dump(node);
  }

  //initialize log file name
  loggingfunc("logfile","Logfile received", bt_args.log_file);

  size_t len = strlen(bt_args.save_file);


  //main client loop
  printf("Starting Main Loop\n");
    //try to accept incoming connection from new peer
      //if seeder

	  if(len > 0)
	  	  leecherCode(node, bt_args);

	  if(len == 0)
	  	  seederCode(node, bt_args);
		

  return 0;
}
