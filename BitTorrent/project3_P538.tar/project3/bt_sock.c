#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <netinet/in.h>
#include <netinet/ip.h> //ip header library (must come before ip_icmp.h)
#include <netinet/ip_icmp.h> //icmp header
#include <arpa/inet.h> //internet address library
#include <netdb.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <signal.h>


#include "bencode.h"
#include "bt_lib.h"
#include "bt_setup.h"
#include "log.h"

#define MSG_BUF_LEN 1024
#define BITFIELD_LEN 16

char * serialize(struct bt_msg  msg)
{
	char * data;
	int ch;

	data = malloc(sizeof(msg));
	ch = msg.bt_type;
	    switch (ch) {
	    case 0: //Choke
	    	sprintf(data, "%u:%d", msg.bt_type, msg.length);
	    	return data;
	      break;
	    case 1: //Unchoke
	    	sprintf(data, "%u:%d", msg.bt_type, msg.length);
	    	return data;
	    	exit(0);
	      break;
	    case 2: //Interested
	    	sprintf(data, "%u:%d", msg.bt_type, msg.length);
	    	return data;
	      break;
	    case 3://Not Interested
	    	sprintf(data, "%u:%d", msg.bt_type, msg.length);
	    	return data;
	      break;
	    case 4://Have
	    	sprintf(data, "%u:%d:%d", msg.bt_type, msg.length, msg.payload.have);
	    	return data;
	      break;
	    case 5://Bitfield
	    	sprintf(data, "%s:%u", msg.payload.bitfiled.bitfield, msg.payload.bitfiled.size);
	    	return data;
	      break;
	    case 6://Request
	    	sprintf(data, "%d:%d:%d", msg.payload.request.begin, msg.payload.request.index, msg.payload.request.length);
	    	return data;
	      break;
	    case 7://Piece
	    	sprintf(data, "%d:%d:%s", msg.payload.piece.begin, msg.payload.piece.index, msg.payload.piece.piece[0]);
	    	return data;
	      break;
	    case 8://Cancel
	    	sprintf(data, "%d:%d:%d", msg.payload.cancel.begin, msg.payload.cancel.index, msg.payload.cancel.length);
	    	return data;
	      break;
	    default:
	      fprintf(stderr,"ERROR: Unknown option '-%c'\n",ch);
	      printf("DEFAULT");
	      usage(stdout);
	      exit(1);
	    }
	return data;
}

struct bt_msg deserialize(char* msg)
{
	struct bt_msg data;
	char *datastring;
	datastring = strtok(msg,":");
	data.bt_type=atoi(datastring);
	datastring = strtok(NULL,":");
	data.length=atoi(datastring);
	int ch = data.bt_type;
		    switch (ch) {
		    case 0: //Choke
		    	return data;
		      break;
		    case 1: //Unchoke
		    	return data;
		      break;
		    case 2: //Interested
		    	return data;
		      break;
		    case 3://Not Interested
		    	return data;
		      break;
		    case 4://Have
		    	datastring = strtok(NULL,":");
		    	data.payload.have=atoi(datastring);
		    	return data;
		      break;
		    case 5://Bitfield
		    	datastring = strtok(NULL,":");
		    	data.payload.bitfiled.bitfield = atoi(datastring);
		    	datastring = strtok(NULL,":");
		    	data.payload.bitfiled.size = atoi(datastring);
		    	return data;
		      break;
		    case 6://Request
		    	datastring = strtok(NULL,":");
		    	data.payload.request.begin = atoi(datastring);
		    	datastring = strtok(NULL,":");
		    	data.payload.request.index = atoi(datastring);
		    	datastring = strtok(NULL,":");
		    	data.payload.request.length = atoi(datastring);
		    	return data;
		      break;
		    case 7://Piece
		    	datastring = strtok(NULL,":");
				data.payload.piece.begin = atoi(datastring);
				datastring = strtok(NULL,":");
				data.payload.piece.index = atoi(datastring);
//				datastring = strtok(NULL,":");
//				data.payload.piece.piece= datastring;
		    	return data;
		      break;
		    case 8://Cancel
		    	datastring = strtok(NULL,":");
				data.payload.cancel.begin = atoi(datastring);
				datastring = strtok(NULL,":");
				data.payload.cancel.index = atoi(datastring);
				datastring = strtok(NULL,":");
				data.payload.cancel.length = atoi(datastring);
		    	return data;
		      break;
		    default:
		      fprintf(stderr,"ERROR: Unknown option '-%c'\n",ch);
		      printf("DEFAULT");
		      usage(stdout);
		      exit(1);
		    }
	return data;
}

//parse_bt_info(bt_info , node)
//{
//
//}

void seederCode(be_node *node_p, bt_args_t args_p){
    int seederSock;
    int leecherSock;
    int handshakeFlag;
    struct sockaddr_in seederSocketAddress; //seeder address
    struct sockaddr_in leecherSocketAddress; //leecher address
    unsigned short seederPort;
    unsigned int leecherLen;
    char *s, *bufptrs;
    char tempChar[4] = {0};
    s = node_p->val.d[0].val->val.s;	//parsing
    tempChar[0] = s[strlen(s)-4];
    tempChar[1] = s[strlen(s)-3];
    tempChar[2] = s[strlen(s)-2];
    tempChar[3] = s[strlen(s)-1];

            if ((seederSock = socket(AF_INET, SOCK_STREAM, 0)) < 0)
                perror( "socket () failed");
                //s = node_p->val.d[0].val.val.s;

                seederPort = atoi(tempChar);
            // Construct local address structure
                memset(&seederSocketAddress, 0, sizeof(seederSocketAddress));
                seederSocketAddress.sin_family = AF_INET;
                seederSocketAddress.sin_addr.s_addr = htons(INADDR_ANY);
                seederSocketAddress.sin_port = htons(seederPort);

            /* Bind to the local address */
            if (bind(seederSock, (struct sockaddr *)&seederSocketAddress,sizeof(struct sockaddr_in)) < 0)
                perror ( "bind () failed");
            else
            	loggingfunc("Binding","Bind successful.", args_p.log_file);

            /* Mark the socket so it will listen for incoming connections */
                if (listen(seederSock, MAX_CONNECTIONS) < 0)
                    perror("\n listen() failed") ;
                else
                	loggingfunc("Listen","Listen successful.", args_p.log_file);
                for (;;) /* Run forever */
                {
                    leecherLen = sizeof(leecherSocketAddress);
                    /* Set the size of the in-out parameter */
                    /* Wait for a client to connect */
                    if ((leecherSock = accept(seederSock, (struct sockaddr *) &leecherSocketAddress,&leecherLen)) >= 0){
                    	loggingfunc("accept()","accept() successful.", args_p.log_file);
                        handshakeFlag = handleLeecherHandshake(leecherSock,node_p,args_p);

                        if(handshakeFlag==1){
                            handleRequestMessages(leecherSock,node_p,args_p);
                        }

                        //calculate number of pieces:
                        		 long long totalFileLength, pieceLength, pieceNumber;
                        		 bt_info_t btinfo;
                        		 btinfo.length = node_p->val.d[2].val->val.d[0].val->val.i;	//parsing
                        		 totalFileLength = btinfo.length;//parsing
                        		 btinfo.piece_length = node_p->val.d[2].val->val.d[2].val->val.i;	//parsing
                        		 pieceLength = 16000;	//piece length
                        		 pieceNumber = totalFileLength/pieceLength + (totalFileLength % pieceLength != 0);	//number of pieces

                        //sending Bitfield values to leecher
                        		 loggingfunc("Bitfield send","Bitfield send to leecher.", args_p.log_file);
                        		 sendBitfield(pieceNumber, leecherSock);

                        //receive REQUEST msg
                        		 loggingfunc("Request received","Request message received from leecher.", args_p.log_file);
                        		 recvRequest(leecherSock);

                        //calculate number of pieces and send them
                        		  calculateandsendSeeder(leecherSock, totalFileLength, recvmsg);

						close(seederSock);
                        break;
                    }
                    else
                    	loggingfunc("Failed","Accept failed.", args_p.log_file);
            }
                loggingfunc("Termination","Seeder code terminated.", args_p.log_file);
//                close(seederSock);
}

//Bitfield msg
int sendBitfield(int pieceNum, int leecherSoc)
{
	 int k, j;	//populate Bitfield values
	 char bfdata[BITFIELD_LEN+1];
	 for(k=0; k<pieceNum; k++)
	 {
		 bfdata[k] = '1';
	 }
	 for(j=k; j<BITFIELD_LEN; j++)
	 {
		 bfdata[j] = '0';
	 }
	 bfdata[BITFIELD_LEN] = '\0';

	 //send bitfield to leecher:
	 char *bitfieldvalue =  malloc(BITFIELD_LEN+1);
	 bitfieldvalue = bfdata;
	  int sendbitfield = send(leecherSoc, bitfieldvalue, BITFIELD_LEN+1, 0);

	  return 0;
}

//
recvRequest(int leecherS)
{
	bt_msg_t recvmsg;
	  char *reqbuf =  malloc(1024);
	  int requst = recv(leecherS, reqbuf, 1024, 0);
	  recvmsg = deserialize(reqbuf);
}

int calculateandsendSeeder(int leecherSck, int flen, bt_msg_t recvms, bt_piece_t btPiece)
{
		long long numofpieces;
		int w = 0;
		long piecelength = 16000;

		numofpieces = ( flen / piecelength) + (flen % piecelength != 0);

// read data and put in buffer
	   FILE *fd;
	   char *readbuffer = malloc(piecelength), *recvHv = malloc(1);
	   int limit = 16000, pieceIndex = 1;


	   fd = fopen("moby_dick.txt", "r");

//	   // Seek to start of  file
	   fseek(fd, SEEK_SET ,0);	//reads first piece
	   fread (readbuffer, 1, piecelength, fd);

//	   //send file data after read
	   	   //send first piece
	   		int sendPiece1 = send(leecherSck, readbuffer, piecelength, 0);//send piece to seeder

			btPiece.begin = limit;	//offset
			btPiece.index = pieceIndex;		//next piece index


//send second and more pieces
	   	for(w=1; w<numofpieces-1; w++)
	   	{
	   		 limit = limit +1;
	   		 pieceIndex = pieceIndex + w;
	   		btPiece.begin = limit;	//offset
	   		btPiece.index = pieceIndex;		//next piece index

	   		//int sizeofbuffer = (flen % piecelength);	// calculate size of buffer
	   		char *readbuffer2 = malloc(piecelength);

		   fseek(fd ,limit-1, 0);
		   int check = fread (readbuffer2, 1, piecelength, fd);

	   int sendPiece2 = send(leecherSck, readbuffer2, piecelength, 0);//send all pieces to seeder

	   	limit = limit + limit;;	//new offset
	   	}

	   	pieceIndex++;

	   	while(pieceIndex == numofpieces)
	   	{
	   	//send last piece
	   		   		 limit = limit +1;
	   		   		// pieceIndex = pieceIndex +1;
	   		   		btPiece.begin = limit;	//offset
	   		   		btPiece.index = pieceIndex;		//next piece index

	   		   		int sizeofbuffer = flen % piecelength;	// calculate size of buffer
	   		   		char *readbuffer3 = malloc(sizeofbuffer);

	   			   fseek(fd , limit - 3, 0);
	   			   int checks = fread (readbuffer3, 1, sizeofbuffer, fd);

//	   			   readbuffer3[sizeofbuffer-3] = '/0';
	   		   int sendPiece3 = send(leecherSck, readbuffer3, sizeofbuffer, 0);//send all pieces to seeder


	   		   	limit = limit + sizeofbuffer;	//new offset
	   		   	break;
	   	}

	   fclose(fd);

return 0;
}
char *calculateSHA1(char* input){
	char digest[20] = {0};
	char *ch_pointer;

	  //id is just the SHA1 of the ip and port string
	  SHA1(input, strlen(input), digest);
	  char hashkeyChar[20];
	  int i;
	  				 for(i = 0; i < 20; i++)
	  					 sprintf(&hashkeyChar[i], "%02x", (unsigned int)digest[i]);

	  				ch_pointer = &hashkeyChar;
	  return ch_pointer;
}

void handleRequestMessages(int leecherSck, be_node *node_p, bt_args_t args_p)
{
		loggingfunc("Ack received","Ack received. Handshake done.", args_p.log_file);
        char *buff;

		bt_msg_t recvmsgs,sendmsgs;

		//receive INTERESTED request from leecher
		loggingfunc("Interested received","Interested msg request received from leecher.", args_p.log_file);
		char *buffin = malloc(1024);
		int recvInterested = recv(leecherSck, buffin, 1024, 0);
		 recvmsgs = deserialize(buffin);

		 //send Unchoke to leecher
		 char *buffun =  malloc(1024);
		 sendmsgs.bt_type = BT_UNCHOKE;	//The current type of msg is	//
		 sendmsgs.length = 1;	//length of entire communication msg

		 buffun = serialize(sendmsgs);
		 int sendUnchoke = send(leecherSck, buffun, 1024, 0);		//send UNCHOKE to leecher
}

int handleLeecherHandshake(int leecherSock, be_node *node_p, bt_args_t args_p){
    printf("\n In leecher handling code: %d",leecherSock);
    loggingfunc("Leecher code","In leecher handling code.", args_p.log_file);
    int rcvMsgSize;
    char str[68] = {0};
    int flag = 0;
    // receive msg from leecher
    if((rcvMsgSize = recv(leecherSock, str, 68, 0))>=0){
        printf("\n On the Seeder Side: %s",str);
        loggingfunc("Seeder side","On the Seeder Side.", args_p.log_file);
        flag = compareHandShake(str,node_p);
        // this means the values received on the seeder side are correct
    }
    while(rcvMsgSize > 0){
        if(flag == 1){
            //send msg to leecher
            if(send(leecherSock,str,rcvMsgSize,0) != rcvMsgSize){
            	 loggingfunc("Error in send","Error in send.", args_p.log_file);
            }
            flag = 0;
            //checking the final ACK MSG
            if((rcvMsgSize = recv(leecherSock,str,68,0))<0){
            	 loggingfunc("Error in recv","Error in recv.", args_p.log_file);
                return flag;
            }else if(strncmp (str,"ACK",3) == 0){
                flag = 1;
                return flag;
            }
        }else if(flag == 0){
            return flag;
        }
    }
//    close(leecherSock);
    return flag;
}

int compareHandShake(char *str, be_node *node_p){
    char handshake[68] = {0};
    char bitTorrentName[19] = "BitTorrent protocol";
    char reservedBytes[8]= "00000000";
    handshake[0] = 19;
    //strncat(final_string, second_string[ text_position ], text_length);
    strncat(handshake, bitTorrentName, 19);
    strncat(handshake, reservedBytes, 8);
    unsigned char inputString[256] = {0};
        unsigned char digest[20] = {0};
        char *ch_pointer;
        char str1[19];
        snprintf(str1, sizeof(str1), "%lld", node_p->val.d[2].val->val.d[0].val->val.i);
        char str3[19];
        snprintf(str3, sizeof(str3), "%lld", node_p->val.d[2].val->val.d[2].val->val.i);

        strcat(inputString,str1);
        strcat(inputString,node_p->val.d[2].val->val.d[1].val->val.s);
        strcat(inputString,str3);
        strcat(inputString,node_p->val.d[2].val->val.d[3].val->val.s);
          SHA1(inputString, strlen(inputString), digest);
          char hashkeyChar[20];
          int i;
                           for(i = 0; i < 20; i++)
                               sprintf(&hashkeyChar[i], "%02x", (unsigned int)digest[i]);

                          ch_pointer = &hashkeyChar;
         strncat(handshake, hashkeyChar, 20);
         int index=0;
         for(index = 0; index < strlen(handshake); index++){
             if(handshake[i]!=str[i])
                 break;
         }
         if(index==strlen(handshake)){
             return 1;
         }
         else{
             return 0;
         }
}

void leecherCode(be_node *node_p, bt_args_t args_p){
    int i = 0;
    int flag=0;
    int breakFlag = 1;
    //unsigned char dataBuffer[256] = {0};
    loggingfunc("Leecher code","Leecher code.", args_p.log_file);
             int leecherSock;
             if((leecherSock = socket(AF_INET, SOCK_STREAM, 0))<0){
            	 loggingfunc("Socket connection error","Socket connection error.", args_p.log_file);
             }
             for(i=0;i<MAX_CONNECTIONS;i++){
                   if(args_p.peers[i] != NULL && (connect(leecherSock, (struct sockaddr*)&args_p.peers[i]->sockaddr,sizeof(struct sockaddr_in)) < 0))
                       perror("Connect");
                   else if(args_p.peers[i] != NULL){
                       //send leecher handshake
                      flag = sendReceiveLeecherHandshake(leecherSock,node_p, args_p);
                      /**
                       * note after this step the handshake has been established successfully if flag has 1
                       * in the while loop below the leecher will request for packets from the seeder using different messages
                       * the breakFlag parameter is used to break the while loop after the file has been received
                       */
                                if(flag == 1){
                                      while(breakFlag == 1){
                                          // create msg to request then have a SEND command here.
                                              breakFlag =0;

                                              //send and receive messages: Interested and Unchoke
                                              bt_msg_t sendmsgs;
                                              bt_msg_t recvmsgs;

                                              //send INTERESTED to seeder
                                         	 char *buffi = malloc(1024);

											  sendmsgs.bt_type = BT_INTERSTED;
											  sendmsgs.length = 1;

											 buffi = serialize(sendmsgs);
											 int sendInterested = send(leecherSock, buffi, 1024, 0);

											 //receive  UNCHOKE
                                              char *buffu =  malloc(1024);
                                              int recvHave = recv(leecherSock, buffu, 1024, 0);
                                              recvmsgs = deserialize(buffu);

                     						 //receive bitfield from seeder
                                              recvBitfield(leecherSock);

											//send REQUEST for piece to seeder
                                              sendRequest(leecherSock);

											 //get number of pieces
											 int filefulllength = node_p->val.d[2].val->val.d[0].val->val.i;	//parsing

											 receiveLeecher((int)filefulllength, leecherSock, args_p, sendmsg);
											  //receive file from seeder


                                      }

                   }
                 }
             }
		 close(leecherSock);
		 loggingfunc("Termination","Leecher code terminating.", args_p.log_file);
		exit(1);
}

//receive bitfield from seeder
int recvBitfield( int leechers)
{
	bt_bitfield_t btfld;
	char *recvbitfieldvalue =  malloc(BITFIELD_LEN+1);	//receive bitfield
	int recvbitfield = recv(leechers, recvbitfieldvalue, BITFIELD_LEN+1, 0);

	btfld.size = (size_t)(BITFIELD_LEN);	//bit field size set
	btfld.bitfield = recvbitfieldvalue;	// bitfield value received
	return 0;
}

//send REQUEST for piece to seeder
sendRequest(int leecherS)
{
	bt_msg_t sendmsg;
	char *bufferr;
	bufferr = malloc(1024);

	 sendmsg.bt_type = BT_REQUEST;	//The current type of msg is
	 sendmsg.length = 1;	//length of msg
	 sendmsg.payload.request.index = 0;
	 sendmsg.payload.request.begin = 0;
	 sendmsg.payload.request.length = 16000;

	 bufferr = serialize(sendmsg);	//parsing
	 int sendReq = send(leecherS, bufferr, 1024, 0);	//send REQUEST to seeder
}
//receive pieces from seeder
int receiveLeecher(int flen, int leecherS, bt_args_t args_p, bt_msg_t recvMs , be_node *node_p)
{
	int limit = 15999, pieceLength = 16000;
	char* digest;
	 FILE *fs, *ffd, *fmd;
	 int w=0;
	long numofpieces = ( flen / pieceLength) + (flen % pieceLength != 0);	// Calculate no. of pieces

	  char *recvfilebuffer = malloc(flen);
	  int recvfile = recv(leecherS, recvfilebuffer, pieceLength, 0);

	  char recvnow[sizeof(recvfilebuffer)];
	  //write to file
	   char *outputbuf = malloc(flen);
	   outputbuf = recvfilebuffer;

	   //if file length < piece length
	   if(flen < pieceLength)
	   {
		   numofpieces = 1;
		   pieceLength = flen;
	   }

	   //first buffer
	   ffd = fopen(args_p.save_file, "w");
		fwrite(outputbuf, 1, pieceLength, ffd);		// receive first piece
		fclose(ffd);

		//receive more pieces
		fs = fopen(args_p.save_file, "a");

		for(w=1; w<numofpieces-1; w++)
			   	{
				//int sizeofbuffer = flen % pieceLength;
				char *outputbuf2 = malloc(pieceLength);
					  int recvfile2 = recv(leecherS, outputbuf2, pieceLength, 0);
					  
				digest = calculateSHA1(outputbuf2);
				//strcat(lengthOfPiece,outputbuf2);
				fwrite(outputbuf2, 1, pieceLength, fs);
				}
		fclose(fs);

			w++;

			//receive last piece
			fmd = fopen(args_p.save_file, "a");
			while(w == numofpieces)
			{
						long sizeofnbuffer = flen % pieceLength;

						char *outputbuf3 = malloc(sizeofnbuffer);
							  int recvfile3 = recv(leecherS, outputbuf3, sizeofnbuffer, 0);

							  outputbuf3[sizeofnbuffer] = '\0';

						fwrite(outputbuf3, 1, sizeofnbuffer, fmd);
						break;
			}
			fclose(fmd);


				return 0;
}

char* calculateSHA1Info(be_dict dictType){
    unsigned char inputString[256] = {0};
    unsigned char digest[20] = {0};
    char *ch_pointer;
    char str1[19];
    snprintf(str1, sizeof(str1), "%lld", dictType.val->val.d[0].val->val.i);
    char str3[19];
    snprintf(str3, sizeof(str3), "%lld", dictType.val->val.d[2].val->val.i);

    strcat(inputString,str1);
    strcat(inputString,dictType.val->val.d[1].val->val.s);
    strcat(inputString,str3);
    strcat(inputString,dictType.val->val.d[3].val->val.s);
    //format print

      //id is just the SHA1 of the ip and port string
      SHA1(inputString, strlen(inputString), digest);
      char hashkeyChar[20];
      int i;
                       for(i = 0; i < 20; i++)
                           sprintf(&hashkeyChar[i], "%02x", (unsigned int)digest[i]);

                      ch_pointer = &hashkeyChar;
      return ch_pointer;
}

int sendReceiveLeecherHandshake(int socketId, be_node *node_p, bt_args_t args_p){
    char handshake[68] = {0};
    char bitTorrentName[19] = "BitTorrent protocol";
    char reservedBytes[8]= "00000000";
    handshake[0] = 19;
    int flagToCheckValidHandshake = 0;
    //strncat(final_string, second_string[ text_position ], text_length);
    strncat(handshake, bitTorrentName, 19);
    strncat(handshake, reservedBytes, 8);
    strncat(handshake, calculateSHA1Info(node_p->val.d[2]), 20);
    strncat(handshake, args_p.peers[1]->id, 20);
    // Write the 68 byte PeerWire handshake.
     send(socketId,handshake, 68,0);
     //receive the response of the handshake
     recv(socketId,handshake,68,0);
     flagToCheckValidHandshake = compareHandShake(handshake,node_p);
     if(flagToCheckValidHandshake == 1){
         //send final ack msg
         send(socketId,"ACK", 68,0);
         return 1;
     }else{
         return 0;
     }
}

int main (int argc, char * argv[]){

  bt_args_t bt_args;
  be_node * node; // top node in the bencoding
  int i;

  parse_args(&bt_args, argc, argv);

  if(bt_args.verbose){
    printf("Args:\n");
    printf("verbose: %d\n",bt_args.verbose);
    printf("save_file: %s\n",bt_args.save_file);
    printf("log_file: %s\n",bt_args.log_file);
    printf("torrent_file: %s\n", bt_args.torrent_file);

    for(i=0;i<MAX_CONNECTIONS;i++){
      if(bt_args.peers[i] != NULL)
        print_peer(bt_args.peers[i]);
    }
  }

  //read and parse the torrent file
  node = load_be_node(bt_args.torrent_file);
  if(bt_args.verbose){
    be_dump(node);
  }

  size_t len = strlen(bt_args.save_file);

  //main client loop
  printf("\n Starting Main Loop\n");

      if(len > 0)
            leecherCode(node, bt_args);

      if(len == 0)
            seederCode(node, bt_args);

  return 0;
}
