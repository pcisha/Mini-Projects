/*
 *
 *  Created on: Oct 20, 2013
 *      Author: oliver
 */
#include "log.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include "bt_setup.h"

// file log.c
void loggingfunc(const char* tag, const char* message, const char *LOG_FILE_NAME) {
	char dataPart[256] = {0};
	FILE *fptr;
	fptr = fopen(LOG_FILE_NAME, "ab+");
	if(fptr == NULL) //if file does not exist, create it
	{
	      fptr = fopen(LOG_FILE_NAME, "ab+");
	}
	time_t current_time;
	char* c_time_string;
	/* Obtain current time as seconds elapsed since the Epoch. */
	current_time = time(NULL);
  //  char _buf[250];
    /* Convert to local time format. */
    c_time_string = ctime(&current_time);
    c_time_string[strlen(c_time_string)-1]="\n";
  // strftime(_buf, 250, "%c", &_calendar_time);
    strcat(dataPart,c_time_string);
    strcat(dataPart,"[");
    strcat(dataPart,tag);
    strcat(dataPart,"]");
    strcat(dataPart,message);
    strcat(dataPart,"\n");
    fputs(dataPart, fptr);
    fclose(fptr);
  // printf("%s [%s]: %s\n", c_time_string, tag, message);
}

