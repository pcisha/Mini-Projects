/*
 * log.h
 *
 *  Created on: Oct 20, 2013
 *      Author: oliver
 */

#ifndef LOG_H_
#define LOG_H_


void loggingfunc(const char* tag, const char* message, const char *logfile_name);


#endif /* LOG_H_ */
