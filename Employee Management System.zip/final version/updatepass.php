<?php
	$employeeid = $_GET['employeeid'];
	
	$password = $_GET['password'];
	
	$dbc = mysqli_connect('localhost', 'root', '', 'employeemanagement')
    or die('Error connecting to MySQL server.');

  $query = "UPDATE AUTHENTICATE SET password=$password WHERE employee_id=$employeeid";

  $result = mysqli_query($dbc, $query)
    or die('Error querying database.');
	
		$output =  array('result'=>$result);
	
	echo json_encode($output,JSON_FORCE_OBJECT);

	mysqli_close($dbc);
?>