// 
// See coeffs.c for explanation of what each of these is for. 
//
double afun(double x,double y);
double bfun(double x,double y);
double cfun(double x,double y);
double dfun(double x,double y);
double efun(double x,double y);
double ffun(double x,double y);
double   BC(double x,double y);
