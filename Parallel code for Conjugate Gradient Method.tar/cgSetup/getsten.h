void getsten(double x, double y, int meshpoints, double stencil[6]);
